/* ═══════════════════════════════════════════════
   EcoTrack AI — settings.js
   Routines, emergency contacts, OTP, validation
   ═══════════════════════════════════════════════ */

/* ROUTINES */
function renderRoutines(){
  var c=document.getElementById('routines-list');if(!c)return;c.innerHTML='';
  var icons={w:'briefcase',f:'target',h:'home',c:'stars'};
  routines.forEach(function(r){
    var d=document.createElement('div');d.className='routine-item';
    d.innerHTML='<div class="ri-icon ri-'+r.type+'"><i class="ti ti-'+(icons[r.type]||'clock')+'"></i></div><div class="ri-info"><div class="ri-name">'+r.name+'</div><div class="ri-time">'+r.time+(r.desc?' · '+r.desc:'')+'</div></div><button class="tog '+(r.enabled?'on':'off')+'" onclick="toggleRoutine('+r.id+')"></button>';
    c.appendChild(d);
  });
}
function toggleRoutine(id){var r=routines.find(function(x){return x.id===id});if(r){r.enabled=!r.enabled;renderRoutines();showToast(r.name+' '+(r.enabled?'enabled':'disabled'),'success');}}
function selectMode(btn){document.querySelectorAll('.mode-opt').forEach(function(b){b.className='mode-opt'});selectedMode=btn.getAttribute('data-mode');btn.className='mode-opt sel-'+selectedMode;}
function toggleDay(btn){btn.classList.toggle('sel')}
function saveNewRoutine(){
  var n=document.getElementById('ar-name'),t=document.getElementById('ar-time'),d=document.getElementById('ar-desc');
  if(!n||!n.value.trim()){showToast('Enter routine name','error');return;}
  if(!t||!t.value){showToast('Set a time','error');return;}
  var h=parseInt(t.value.split(':')[0]),m=t.value.split(':')[1],ampm=h>=12?'PM':'AM';h=h%12||12;
  routines.push({id:Date.now(),name:n.value.trim(),time:(h<10?'0':'')+h+':'+m+' '+ampm,desc:d?d.value.trim():'',type:selectedMode,enabled:true});
  renderRoutines();if(n)n.value='';if(t)t.value='';if(d)d.value='';
  goBack();showToast('Routine added! ✅','success');
}

/* EMERGENCY CONTACTS */
function renderEmergencyContacts(){
  var list=document.getElementById('ec-list');if(!list)return;list.innerHTML='';
  emergencyContacts.forEach(function(c){
    var avCls=c.status==='primary'?'eca-primary':(c.status==='verified'?'eca-verified':'eca-pending');
    var bdCls=c.status==='primary'?'ecb-primary':(c.status==='verified'?'ecb-verified':'ecb-pending');
    var bdTxt=c.status==='primary'?'Primary':(c.status==='verified'?'✓ Verified':'⏳ Pending');
    var del=c.status==='primary'?'':'<button class="ec-del" onclick="deleteEcContact('+c.id+')"><i class="ti ti-x"></i></button>';
    var div=document.createElement('div');div.className='ec-contact';
    div.innerHTML='<div class="ec-avatar '+avCls+'">'+(c.name.charAt(0).toUpperCase())+'</div><div class="ec-info"><div class="ec-email">'+c.email+'</div><div class="ec-role">'+c.role+(c.name&&c.name!=='Primary'?' · '+c.name:'')+'</div></div><span class="ec-badge '+bdCls+'">'+bdTxt+'</span>'+del;
    list.appendChild(div);
  });
  var lbl=document.getElementById('ec-count-label');var v=emergencyContacts.filter(function(c){return c.status!=='pending'}).length;if(lbl)lbl.textContent=v+' contacts verified';
}
function showEcForm(){document.getElementById('ec-add-form').style.display='block';document.getElementById('ec-add-btn').style.display='none';document.getElementById('ec-form-step1').style.display='block';document.getElementById('ec-form-step2').style.display='none';}
function hideEcForm(){document.getElementById('ec-add-form').style.display='none';document.getElementById('ec-add-btn').style.display='flex';}
var pendingEcEmail='',pendingEcName='';
function sendEcOTP(){var em=document.getElementById('ec-new-email');if(!em||!validateEmailStr(em.value)){showToast('Enter valid email','error');return;}pendingEcEmail=em.value;pendingEcName=document.getElementById('ec-new-name').value||em.value.split('@')[0];var t=document.getElementById('ec-otp-target');if(t)t.textContent=pendingEcEmail;document.getElementById('ec-form-step1').style.display='none';document.getElementById('ec-form-step2').style.display='block';clearOtpBoxes('ec');showToast('OTP sent to '+pendingEcEmail,'success');}
function verifyEcOTP(){var boxes=document.querySelectorAll('#ec-form-step2 .otp-box');var otp='';boxes.forEach(function(b){otp+=b.value});if(otp.length<6){showToast('Enter complete OTP','error');return;}emergencyContacts.push({id:Date.now(),name:pendingEcName,email:pendingEcEmail,role:'Emergency Contact',status:'verified'});renderEmergencyContacts();hideEcForm();showToast(pendingEcEmail+' verified & added! ✅','success');}
function deleteEcContact(id){emergencyContacts=emergencyContacts.filter(function(c){return c.id!==id});renderEmergencyContacts();showToast('Contact removed','success');}

/* ACTIVE DEVICES */
function renderActiveDevices(){
  var c=document.getElementById('adl-device-list');if(!c)return;c.innerHTML='';
  var icons={mobile:'device-mobile',laptop:'device-laptop',tablet:'device-ipad'};
  var statColors={alert:'var(--red)',warning:'var(--orange)',online:'var(--green)'};
  var statText={alert:'ALERT',warning:'WARNING',online:'ONLINE'};
  activeDevices.forEach(function(d){
    var div=document.createElement('div');div.className='adl-device';
    div.innerHTML='<div class="adl-icon" style="background:linear-gradient(135deg,#001628,#001a33)"><i class="ti ti-'+(icons[d.type]||'device-mobile')+'" style="color:'+d.color+'"></i></div><div class="adl-info"><div class="adl-name">'+d.name+'</div><div class="adl-detail">'+d.detail+'</div></div><span class="adl-status" style="background:'+d.color+'22;color:'+d.color+';border:1px solid '+d.color+'44">'+statText[d.status]+'</span><button class="adl-remove" onclick="removeDevice('+d.id+')" title="Remove"><i class="ti ti-x"></i></button>';
    c.appendChild(div);
  });
  var lbl=document.getElementById('device-count-label');if(lbl)lbl.textContent=activeDevices.length+' devices connected';
}
function removeDevice(id){activeDevices=activeDevices.filter(function(d){return d.id!==id});renderActiveDevices();showToast('Device removed','success');}

/* OTP HELPERS */
function otpNext(input,ctx){
  if(input.value.length>=1){
    var sel={'fp':'#fp-otp-inputs .otp-box','ec':'#ec-form-step2 .otp-box','sv':'#sv-otp-inputs .otp-box'};
    var boxes=document.querySelectorAll(sel[ctx]||'');var idx=Array.from(boxes).indexOf(input);
    if(idx<boxes.length-1)boxes[idx+1].focus();
  }
}
function clearOtpBoxes(ctx){var sel={'fp':'#fp-otp-inputs .otp-box','ec':'#ec-form-step2 .otp-box','sv':'#sv-otp-inputs .otp-box'};document.querySelectorAll(sel[ctx]||'').forEach(function(b){b.value=''});var f=document.querySelector(sel[ctx]||'');if(f)f.focus();}
function resendOTP(ctx){showToast('OTP resent!','success');clearOtpBoxes(ctx);}

/* VALIDATION */
function validateEmailStr(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)}
function markField(id,state){var w=document.getElementById(id);if(!w)return;w.classList.remove('valid','error');if(state)w.classList.add(state)}
function validateEmail(ctx){var id=ctx+'-email-wrap';var inp=document.getElementById(ctx+'-email');if(!inp)return;markField(id,inp.value?(validateEmailStr(inp.value)?'valid':'error'):'');}
function validateName(){var inp=document.getElementById('reg-name');markField('reg-name-wrap',inp.value.length>=2?'valid':(inp.value?'error':''))}
function validateConfirmPass(){var p=document.getElementById('reg-pass');var cp=document.getElementById('reg-cpass');if(!p||!cp)return;markField('reg-cpass-wrap',cp.value&&cp.value===p.value?'valid':(cp.value?'error':''))}
function validatePassStrength(){
  var inp=document.getElementById('reg-pass');if(!inp)return;var v=inp.value;
  var w=document.getElementById('strength-wrap');var f=document.getElementById('strength-fill');var t=document.getElementById('strength-txt');
  if(!v){if(w)w.style.display='none';return;}if(w)w.style.display='block';
  var score=0;if(v.length>=8)score++;if(/[A-Z]/.test(v))score++;if(/[0-9]/.test(v))score++;if(/[^A-Za-z0-9]/.test(v))score++;
  var labels=['Weak','Fair','Good','Strong'],colors=['#ff3344','#ff8800','#ffcc00','#00cc77'],pct=[25,50,75,100];
  if(f){f.style.width=(pct[score-1]||5)+'%';f.style.background=colors[score-1]||'#ff3344';}
  if(t){t.textContent=labels[score-1]||'Too Short';t.style.color=colors[score-1]||'#ff3344';}
  markField('reg-pass-wrap',score>=3?'valid':(v?'error':''));
}
function toggleEye(inputId,iconId){var inp=document.getElementById(inputId);var ico=document.getElementById(iconId);if(!inp)return;var showing=inp.type==='text';inp.type=showing?'password':'text';if(ico)ico.className='ti '+(showing?'ti-eye':'ti-eye-off');}

