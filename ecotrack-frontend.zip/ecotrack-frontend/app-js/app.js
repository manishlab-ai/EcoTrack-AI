/* ═══════════════════════════════════════════════
   EcoTrack AI — app.js
   Core: init, navigation, theme, language, toast, clock
   ═══════════════════════════════════════════════ */

/* ── API PLACEHOLDER LAYER ──────────────────────
  TODO: Replace stubs below with real endpoints

  POST /auth/login          → { email, password }          → { userId, token }
  POST /auth/register       → { name, email, phone, pwd }  → { userId, token }
  POST /auth/new-reg        → { org, role, device, email, pwd } → { agentId, token }
  GET  /devices             →                               → [{ id, name, status, battery, gsm, gps }]
  POST /devices/:id/command → { cmd: ring|lock|erase }     → { success, timestamp }
  POST /auth/forgot         → { email }                    → { sent: true }
  POST /auth/verify-otp     → { email, otp }               → { verified: true }
  GET  /emergency-contacts  →                               → [{ id, email, status }]
  POST /emergency-contacts  → { email, name }              → { id, otp_sent: true }
  GET  /location/online     →                               → { lat, lon, accuracy }  (Google Find My Device)
  GET  /location/offline    →                               → { rssi, distance, hot_cold }  (BLE)
──────────────────────────────────────────────── */

var LANGS=[
  {code:'en',name:'English',flag:'🇬🇧',dir:'ltr'},{code:'hi',name:'हिन्दी',flag:'🇮🇳',dir:'ltr'},
  {code:'es',name:'Español',flag:'🇪🇸',dir:'ltr'},{code:'fr',name:'Français',flag:'🇫🇷',dir:'ltr'},
  {code:'de',name:'Deutsch',flag:'🇩🇪',dir:'ltr'},{code:'zh',name:'中文',flag:'🇨🇳',dir:'ltr'},
  {code:'ja',name:'日本語',flag:'🇯🇵',dir:'ltr'},{code:'ar',name:'العربية',flag:'🇸🇦',dir:'rtl'},
  {code:'ru',name:'Русский',flag:'🇷🇺',dir:'ltr'},{code:'pt',name:'Português',flag:'🇧🇷',dir:'ltr'},
  {code:'id',name:'Indonesia',flag:'🇮🇩',dir:'ltr'},{code:'bn',name:'বাংলা',flag:'🇧🇩',dir:'ltr'},
  {code:'ur',name:'اردو',flag:'🇵🇰',dir:'rtl'},{code:'ko',name:'한국어',flag:'🇰🇷',dir:'ltr'},
  {code:'tr',name:'Türkçe',flag:'🇹🇷',dir:'ltr'},{code:'vi',name:'Tiếng Việt',flag:'🇻🇳',dir:'ltr'},
  {code:'it',name:'Italiano',flag:'🇮🇹',dir:'ltr'},{code:'pl',name:'Polski',flag:'🇵🇱',dir:'ltr'},
  {code:'nl',name:'Nederlands',flag:'🇳🇱',dir:'ltr'},{code:'th',name:'ภาษาไทย',flag:'🇹🇭',dir:'ltr'},
  {code:'he',name:'עברית',flag:'🇮🇱',dir:'rtl'},{code:'fa',name:'فارسی',flag:'🇮🇷',dir:'rtl'},
  {code:'ms',name:'Melayu',flag:'🇲🇾',dir:'ltr'},{code:'ta',name:'தமிழ்',flag:'🇮🇳',dir:'ltr'},
  {code:'te',name:'తెలుగు',flag:'🇮🇳',dir:'ltr'},{code:'mr',name:'मराठी',flag:'🇮🇳',dir:'ltr'},
  {code:'sv',name:'Svenska',flag:'🇸🇪',dir:'ltr'},{code:'uk',name:'Українська',flag:'🇺🇦',dir:'ltr'},
  {code:'ro',name:'Română',flag:'🇷🇴',dir:'ltr'},{code:'cs',name:'Čeština',flag:'🇨🇿',dir:'ltr'}
];

var T={
  en:{tagline:'Sentinel-Logic · Autonomous Device Guardian',signin_title:'Sign in to Sentinel',signin_sub:'Verified device access required',email_label:'Email Address',pass_label:'Password',forgot_pass:'Forgot password?',signin_btn:'Sign In to Sentinel',or_continue:'or continue with',google_btn:'Sign in with Google',new_user:'New device?',register_link:'Register',new_reg_link:'New Registration',reg_title:'Create Account',reg_sub:'Join the Sentinel network',fullname_label:'Full Name',phone_label:'Phone Number',confirm_pass:'Confirm Password',terms_agree:'I agree to the Terms & Conditions and Privacy Policy',create_account:'Create Account',have_account:'Already have an account?',signin_link:'Sign In',home:'Home',device:'Device',routine:'Routine',settings:'Settings',workflow_trace:'Agentic Workflow Trace',voice_cmd:'Voice Command · Live GPS Map',adv_vitals:'Advanced Sentinel Vitals',ring:'RING',closed_loop:'CLOSED-LOOP',lock_device:'LOCK DEVICE',erase_data:'ERASE DATA',sys_vitals:'System Vitals',daily_schedule:'Daily Schedule',activity_logs:'Activity Logs',privacy_guard:'Privacy Guard',smart_routines:'Smart Routines',sentinel_devices:'Sentinel Devices',dark_mode:'Dark Mode',language:'Language',notifications:'Notifications',add_routine:'Add / Edit Custom Routine'},
  hi:{tagline:'सेंटिनल-लॉजिक · स्वायत्त डिवाइस गार्डियन',signin_title:'सेंटिनल में साइन इन',signin_sub:'सत्यापित एक्सेस आवश्यक',email_label:'ईमेल पता',pass_label:'पासवर्ड',forgot_pass:'पासवर्ड भूल गए?',signin_btn:'सेंटिनल में साइन इन करें',or_continue:'या जारी रखें',google_btn:'Google से साइन इन',new_user:'नया डिवाइस?',register_link:'रजिस्टर',new_reg_link:'नया पंजीकरण',reg_title:'खाता बनाएं',reg_sub:'सेंटिनल नेटवर्क से जुड़ें',fullname_label:'पूरा नाम',phone_label:'फ़ोन नंबर',confirm_pass:'पासवर्ड की पुष्टि',terms_agree:'मैं नियम और गोपनीयता नीति से सहमत हूं',create_account:'खाता बनाएं',have_account:'पहले से खाता है?',signin_link:'साइन इन',home:'होम',device:'डिवाइस',routine:'रूटीन',settings:'सेटिंग्स',ring:'रिंग',lock_device:'लॉक',erase_data:'मिटाएं',sys_vitals:'सिस्टम विटल्स'},
  es:{tagline:'Sentinel-Logic · Guardián Autónomo',signin_title:'Iniciar sesión en Sentinel',signin_sub:'Acceso verificado requerido',email_label:'Correo electrónico',pass_label:'Contraseña',forgot_pass:'¿Olvidaste la contraseña?',signin_btn:'Iniciar sesión',or_continue:'o continuar con',google_btn:'Iniciar con Google',new_user:'¿Nuevo dispositivo?',register_link:'Registrarse',new_reg_link:'Nuevo Registro',home:'Inicio',device:'Dispositivo',routine:'Rutina',settings:'Configuración',ring:'LLAMAR',lock_device:'BLOQUEAR',erase_data:'BORRAR'},
  ar:{tagline:'سنتينل-لوجيك · حارس الأجهزة',signin_title:'تسجيل الدخول',signin_sub:'مطلوب وصول محقق',email_label:'البريد الإلكتروني',pass_label:'كلمة المرور',forgot_pass:'نسيت كلمة المرور؟',signin_btn:'تسجيل الدخول',or_continue:'أو المتابعة',google_btn:'بجوجل',home:'الرئيسية',device:'الجهاز',routine:'الروتين',settings:'الإعدادات',ring:'رنين',lock_device:'قفل',erase_data:'مسح'}
};

var curLang='en',curTheme='dark',openMenuId=null,pendingAction=null,navHistory=[],curMapMode='online',selectedMode='w';

(function init(){
  setTheme('dark');
  renderLangLists();
  renderSettingsLangs(LANGS);
  updateClock();
  setInterval(updateClock,1000);
  applyLang('en');
  renderRoutines();
  renderEmergencyContacts();
  renderActiveDevices();
  document.addEventListener('click',function(e){if(!e.target.closest('.lang-dropdown-wrap'))closeAllMenus()});
})();

/* NAVIGATION */
function goTo(id){
  var cur=document.querySelector('.screen.active');
  if(cur&&cur.id!==id)navHistory.push(cur.id);
  document.querySelectorAll('.screen').forEach(function(s){s.classList.remove('active')});
  var el=document.getElementById(id);
  if(el)el.classList.add('active');
}
function goBack(){
  if(navHistory.length>0){var p=navHistory.pop();document.querySelectorAll('.screen').forEach(function(s){s.classList.remove('active')});var el=document.getElementById(p);if(el)el.classList.add('active')}
  else goTo('sc-home');
}
function switchTab(tab,btn){
  goTo('sc-'+tab);
  if(btn){btn.closest('.bottom-tab-bar').querySelectorAll('.tab-btn').forEach(function(b){b.classList.remove('active')});btn.classList.add('active')}
  updateDesktopNav(tab);
}
function navTo(tab){
  closeSidebar();
  var map={settings:'sc-settings',userManual:'sc-userManual',emergency:'sc-emergency',about:'sc-about',loginPage:'sc-loginPage',activeDevices:'sc-activeDevices',home:'sc-home',device:'sc-device',routine:'sc-routine'};
  if(map[tab])goTo(map[tab]);
  updateDesktopNav(tab);
}
function updateDesktopNav(tab){
  document.querySelectorAll('.dn-item').forEach(function(i){i.classList.remove('active')});
  var dn=document.getElementById('dn-'+tab);
  if(dn)dn.classList.add('active');
}

/* SIDEBAR */

/* THEME */
function setTheme(t){
  curTheme=t;
  document.documentElement.setAttribute('data-theme',t);
  var isDark=t==='dark';
  var icon=isDark?'ti-sun':'ti-moon';
  ['theme-icon-login','theme-icon-reg','theme-icon-newreg','theme-icon-home','theme-icon-forgot','dn-theme-icon'].forEach(function(id){var el=document.getElementById(id);if(el)el.className='ti '+icon});
  var stl=document.getElementById('settings-theme-tog');if(stl)stl.className=isDark?'tog on':'tog off';
  var stll=document.getElementById('theme-status-label');if(stll)stll.textContent=isDark?'Enabled':'Disabled';
}
function toggleTheme(){setTheme(curTheme==='dark'?'light':'dark')}

/* LANGUAGE */

/* LANGUAGE */
function renderLangLists(){['login','reg','newreg','home','desktop'].forEach(function(ctx){renderList(ctx,LANGS)})}
function renderList(ctx,list){
  var c=document.getElementById('lang-list-'+ctx);if(!c)return;c.innerHTML='';
  list.forEach(function(l){var d=document.createElement('div');d.className='lang-option'+(l.code===curLang?' active':'');d.innerHTML='<span class="flag">'+l.flag+'</span> '+l.name;d.onclick=function(e){e.stopPropagation();selectLang(l.code);closeAllMenus()};c.appendChild(d)});
}
function filterLangs(q,ctx){renderList(ctx,LANGS.filter(function(l){return l.name.toLowerCase().indexOf(q.toLowerCase())>-1}))}
function toggleLangMenu(ctx){
  var menuId='lang-menu-'+ctx;
  if(openMenuId&&openMenuId!==menuId){var old=document.getElementById(openMenuId);if(old)old.style.display='none';}
  var m=document.getElementById(menuId);if(!m)return;
  var showing=m.style.display==='block';m.style.display=showing?'none':'block';openMenuId=showing?null:menuId;
  if(!showing){var inp=m.querySelector('input');if(inp){inp.value='';filterLangs('',ctx);}}
}
function closeAllMenus(){document.querySelectorAll('.lang-dropdown').forEach(function(m){m.style.display='none'});openMenuId=null}
function renderSettingsLangs(list){
  var g=document.getElementById('settings-lang-grid');if(!g)return;g.innerHTML='';
  list.forEach(function(l){var b=document.createElement('button');b.style.cssText='padding:5px 10px;border-radius:7px;border:1px solid '+(l.code===curLang?'var(--cyan)':'var(--brd)')+';color:'+(l.code===curLang?'var(--cyan)':'var(--lo)')+';background:'+(l.code===curLang?'#00d4ff12':'none')+';font-size:10px;cursor:pointer;font-family:Inter,sans-serif;transition:all .2s;display:flex;align-items:center;gap:4px';b.innerHTML='<span>'+l.flag+'</span><span>'+l.name+'</span>';b.onclick=function(){selectLang(l.code)};g.appendChild(b)});
}
function filterSettingsLangs(q){renderSettingsLangs(LANGS.filter(function(l){return l.name.toLowerCase().indexOf(q.toLowerCase())>-1||l.code.indexOf(q.toLowerCase())>-1}))}
function selectLang(code){
  curLang=code;var l=LANGS.find(function(x){return x.code===code});if(!l)return;
  document.documentElement.setAttribute('dir',l.dir);
  ['login','reg','newreg','home','desktop'].forEach(function(ctx){var lbl=document.getElementById('lang-label-'+ctx);if(lbl)lbl.textContent=code.toUpperCase();renderList(ctx,LANGS)});
  renderSettingsLangs(LANGS);applyLang(code);showToast('Language: '+l.name,'success');
}
function applyLang(code){
  var dict=T[code]||T['en'];
  document.querySelectorAll('[data-i18n]').forEach(function(el){var key=el.getAttribute('data-i18n');var val=dict[key]||(T['en'][key]||'');if(val)el.textContent=val});
}

/* AUTH */

/* TOAST */
var toastTimer;
function showToast(msg,type){
  var t=document.getElementById('toast');var m=document.getElementById('toast-msg');if(!t)return;
  if(toastTimer)clearTimeout(toastTimer);m.textContent=msg;t.className='toast show '+(type||'');
  toastTimer=setTimeout(function(){t.className='toast';},2500);
}

/* CLOCK */

/* CLOCK */
function updateClock(){
  var now=new Date();var h=now.getHours(),mi=now.getMinutes();var ampm=h>=12?'PM':'AM';h=h%12||12;
  var str=(h<10?'0':'')+h+':'+(mi<10?'0':'')+mi+' '+ampm;
  var el=document.getElementById('live-clock');if(el)el.textContent=str;
  document.querySelectorAll('.live-clock-d').forEach(function(e){e.textContent=str});
}


