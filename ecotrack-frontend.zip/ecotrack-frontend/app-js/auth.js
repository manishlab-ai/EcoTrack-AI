/* ═══════════════════════════════════════════════
   EcoTrack AI — auth.js
   Login, register, new-reg, forgot password
   ═══════════════════════════════════════════════ */

/* AUTH */
function doLogin(){
  var email=document.getElementById('login-email');var btn=document.getElementById('login-btn-inner');
  if(email&&!validateEmailStr(email.value)){markField('login-email-wrap','error');showToast('Please enter a valid email','error');return;}
  if(btn)btn.innerHTML='<span class="spinner"></span> Authenticating…';
  /* TODO: POST /auth/login → { email, password } */
  setTimeout(function(){
    if(btn)btn.innerHTML='<i class="ti ti-login"></i> Sign In to Sentinel';
    var u=email?email.value:'User126@email.com';
    var lbl=document.getElementById('home-user-label');if(lbl)lbl.textContent=u;
    navHistory=[];goTo('sc-home');showToast('Welcome back! 👋','success');
  },900);
}
function doRegister(){
  if(!document.getElementById('terms-check').checked){showToast('Please accept terms & conditions','error');return;}
  var btn=document.querySelector('#sc-register .login-btn');if(btn)btn.innerHTML='<span class="spinner"></span> Creating account…';
  /* TODO: POST /auth/register */
  setTimeout(function(){if(btn)btn.innerHTML='<i class="ti ti-user-plus"></i> Create Account';navHistory=[];goTo('sc-home');showToast('Account created! Welcome 🎉','success');},1000);
}
function doNewRegister(){
  if(!document.getElementById('newreg-terms').checked){showToast('Please accept terms & conditions','error');return;}
  var btn=document.querySelector('#sc-newreg .login-btn');if(btn)btn.innerHTML='<span class="spinner"></span> Registering…';
  /* TODO: POST /auth/new-reg */
  setTimeout(function(){if(btn)btn.innerHTML='<i class="ti ti-robot"></i> Register Sentinel Agent';navHistory=[];goTo('sc-home');showToast('Sentinel agent registered! ✅','success');},1000);
}

/* FORGOT PASSWORD */
function sendForgotOTP(){
  var em=document.getElementById('fp-email');if(!em||!validateEmailStr(em.value)){markField('fp-email-wrap','error');showToast('Enter a valid email','error');return;}
  document.querySelectorAll('.fp-step').forEach(function(s){s.classList.remove('active')});document.getElementById('fp-step2').classList.add('active');
  var sub=document.getElementById('fp-otp-sub');if(sub)sub.textContent='OTP sent to '+em.value;
  showToast('Reset link sent to '+em.value,'success');
}
function verifyForgotOTP(){
  var boxes=document.querySelectorAll('#fp-otp-inputs .otp-box');var otp='';boxes.forEach(function(b){otp+=b.value});
  if(otp.length<6){showToast('Enter complete OTP','error');return;}
  document.querySelectorAll('.fp-step').forEach(function(s){s.classList.remove('active')});document.getElementById('fp-step3').classList.add('active');
  showToast('OTP verified!','success');
}
function resetPassword(){
  var np=document.getElementById('fp-newpass');var cp=document.getElementById('fp-confirmpass');
  if(!np||np.value.length<8){showToast('Min 8 characters required','error');return;}
  if(np.value!==cp.value){showToast('Passwords do not match','error');return;}
  showToast('Password reset! ✅','success');
  setTimeout(function(){navHistory=[];goTo('sc-login');},1200);
}
function validatePassStrength2(){
  var inp=document.getElementById('fp-newpass');if(!inp)return;
  var v=inp.value;var w=document.getElementById('strength-wrap2');var f=document.getElementById('strength-fill2');var t=document.getElementById('strength-txt2');
  if(!v){if(w)w.style.display='none';return;}if(w)w.style.display='block';
  var score=0;if(v.length>=8)score++;if(/[A-Z]/.test(v))score++;if(/[0-9]/.test(v))score++;if(/[^A-Za-z0-9]/.test(v))score++;
  var labels=['Weak','Fair','Good','Strong'],colors=['#ff3344','#ff8800','#ffcc00','#00cc77'],pct=[25,50,75,100];
  if(f){f.style.width=(pct[score-1]||5)+'%';f.style.background=colors[score-1]||'#ff3344';}
  if(t){t.textContent=labels[score-1]||'Too Short';t.style.color=colors[score-1]||'#ff3344';}
}

