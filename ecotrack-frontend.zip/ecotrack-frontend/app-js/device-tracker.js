/* ═══════════════════════════════════════════════
   EcoTrack AI — device-tracker.js
   Secure modal, lock/erase/logout flows, active devices
   ═══════════════════════════════════════════════ */

/* SECURE MODAL */
function openSecureModal(action){
  pendingAction=action;
  var ico=document.getElementById('sv-ico'),tit=document.getElementById('sv-title'),desc=document.getElementById('sv-desc'),warn=document.getElementById('sv-warning'),lbl=document.getElementById('sv-confirm-lbl'),inp=document.getElementById('sv-type-input');
  var configs={erase:{icon:'ti-trash',color:'var(--red)',title:'Erase Device Data?',desc:'All data permanently deleted.',warn:'⚠️ Irreversible. All device data, settings & history will be wiped.',lbl:'Type ERASE to proceed',ph:'Type ERASE…'},logout:{icon:'ti-logout',color:'var(--orange)',title:'Logout Device?',desc:'You will be signed out.',warn:'⚠️ Security notification sent to emergency contacts.',lbl:'Type LOGOUT to proceed',ph:'Type LOGOUT…'},lock:{icon:'ti-lock',color:'var(--orange)',title:'Lock Device?',desc:'Device will be locked remotely.',warn:'⚠️ Locked immediately. Security alert dispatched.',lbl:'Type LOCK to proceed',ph:'Type LOCK…'}};
  var cfg=configs[action]||configs.lock;
  if(ico){ico.className='ti '+cfg.icon;ico.style.color=cfg.color;}
  if(tit)tit.textContent=cfg.title;if(desc)desc.textContent=cfg.desc;if(warn)warn.textContent=cfg.warn;if(lbl)lbl.textContent=cfg.lbl;if(inp){inp.value='';inp.placeholder=cfg.ph;}
  var btn=document.getElementById('sv-next-btn');if(btn){btn.disabled=true;btn.style.opacity='.4';btn.style.cursor='not-allowed';}
  setSvStep(1);document.getElementById('secure-modal').classList.add('open');
}
function closeSecureModal(){document.getElementById('secure-modal').classList.remove('open');pendingAction=null;}
function setSvStep(n){
  for(var i=1;i<=4;i++){var s=document.getElementById('sv-step'+i);if(s)s.className='sec-step'+(i===n?' active':'')}
  var s3a=document.getElementById('sv-step3a'),s3b=document.getElementById('sv-step3b');
  if(s3a)s3a.className='sec-step';if(s3b)s3b.className='sec-step';
}
function checkConfirmWord(){
  var inp=document.getElementById('sv-type-input');var btn=document.getElementById('sv-next-btn');
  var exp=pendingAction==='erase'?'ERASE':(pendingAction==='logout'?'LOGOUT':'LOCK');
  var ok=inp.value.trim().toUpperCase()===exp;
  btn.disabled=!ok;btn.style.opacity=ok?'1':'.4';btn.style.cursor=ok?'pointer':'not-allowed';
}
function goToVerifyStep(){setSvStep(2)}
function chooseBiometric(){
  document.getElementById('sv-step2').className='sec-step';document.getElementById('sv-step3a').className='sec-step active';
  var status=document.getElementById('sv-bio-status');if(status)status.textContent='';
  var steps=['Scanning…','Reading biometric…','Verifying…'];var i=0;
  var t=setInterval(function(){if(status)status.textContent=steps[i]||'';i++;if(i>=steps.length){clearInterval(t);setTimeout(function(){if(status)status.textContent='✅ Biometric verified!';setTimeout(showSuccessStep,600)},500);}},700);
}
function chooseOTP(){document.getElementById('sv-step2').className='sec-step';document.getElementById('sv-step3b').className='sec-step active';clearOtpBoxes('sv');showToast('OTP sent to your email','success')}
function verifySecureOTP(){
  var boxes=document.querySelectorAll('#sv-otp-inputs .otp-box');var otp='';boxes.forEach(function(b){otp+=b.value});
  if(otp.length<6){showToast('Enter complete OTP','error');return;}
  showSuccessStep();
}
function showSuccessStep(){
  var st=document.getElementById('sv-success-tit');if(st){var names={erase:'Data Erased',logout:'Logged Out',lock:'Device Locked'};st.textContent=names[pendingAction]||'Action Executed';}
  var cnt=document.getElementById('sv-contact-count');if(cnt)cnt.textContent=emergencyContacts.filter(function(c){return c.status!=='pending'}).length;
  var ts=document.getElementById('sv-timestamp');if(ts)ts.textContent=new Date().toLocaleTimeString();
  setSvStep(4);
}
function executeAction(){
  var action=pendingAction;closeSecureModal();
  var msgs={erase:'Data erased. Alerts sent.',logout:'Logged out. Security alert sent.',lock:'Device locked. Alert sent.'};
  showToast(msgs[action]||'Action completed','success');
  if(action==='logout'){setTimeout(function(){navHistory=[];goTo('sc-login');},800);}
}

