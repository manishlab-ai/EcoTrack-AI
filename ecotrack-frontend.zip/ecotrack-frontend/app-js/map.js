/* ═══════════════════════════════════════════════
   EcoTrack AI — map.js
   Map mode, online/offline tracker, BLE simulation
   ═══════════════════════════════════════════════ */

/* MAP MODE */
function switchMapMode(mode){
  curMapMode=mode;
  var ob=document.getElementById('mmt-online');
  var ofb=document.getElementById('mmt-offline');
  if(mode==='online'){ob.className='mmt-btn active online';ofb.className='mmt-btn offline';document.getElementById('map-label-main').innerHTML='<i class="ti ti-map-pin" style="font-size:12px"></i> Online · Find My Device API';}
  else{ob.className='mmt-btn online';ofb.className='mmt-btn active offline';document.getElementById('map-label-main').innerHTML='<i class="ti ti-bluetooth" style="font-size:12px"></i> Offline · BLE Proximity Tracker';}
  var vb=document.getElementById('voice-banner-txt');
  if(vb)vb.textContent=mode==='online'?'Tap mic → Start Live Track (Online)':'Tap mic → BLE Hot/Cold Radar (Offline)';
}
function openMapOverlay(mode){
  var ol=document.getElementById('map-overlay-'+mode);
  if(ol){closeMapOverlay();ol.classList.add('show');}
  if(mode==='online'){simulateFindDevice();}else{simulateBLE();}
}
function closeMapOverlay(){document.querySelectorAll('.map-overlay').forEach(function(o){o.classList.remove('show')})}
function triggerFindDevice(){
  /* TODO: GET /location/online → Google Find My Device API */
  showToast('Live tracking started via Find My Device API','success');
  var s=document.getElementById('find-status');
  if(s)s.textContent='📍 GPS Acquired — Tracking active…';
}
function simulateFindDevice(){
  var s=document.getElementById('find-status');
  var c=document.getElementById('find-coords');
  var lats=['28.6139','28.6145','28.6132','28.6155'];
  var lons=['77.2090','77.2095','77.2085','77.2098'];
  var i=0;
  var t=setInterval(function(){
    if(!document.getElementById('map-overlay-online').classList.contains('show')){clearInterval(t);return;}
    if(s)s.textContent=i===0?'Acquiring GPS…':(i===1?'Cell tower assist…':(i===2?'High-accuracy GPS locked':'📍 Live tracking…'));
    if(c&&i>0)c.textContent='Lat: +'+lats[i]+'° · Lon: +'+lons[i]+'°';
    i=(i+1)%4;
  },1200);
}
function simulateBLE(){
  var signals=['🔥 HOT — Very close! (<1m)','🌡 WARM — Getting closer (~3m)','❄️ COLD — Moving away (~8m)','🌡 WARM — Getting closer (~4m)'];
  var rssi=['-45 dBm · <1m','-67 dBm · ~3m','-82 dBm · ~8m','-71 dBm · ~4m'];
  var i=0;
  var t=setInterval(function(){
    if(!document.getElementById('map-overlay-offline').classList.contains('show')){clearInterval(t);return;}
    var sig=document.getElementById('ble-signal');
    var dist=document.getElementById('ble-dist');
    var colors=['var(--red)','var(--orange)','var(--cyan)','var(--orange)'];
    if(sig){sig.textContent=signals[i];sig.style.color=colors[i];}
    if(dist)dist.textContent='BLE RSSI: '+rssi[i];
    i=(i+1)%4;
  },1500);
}

